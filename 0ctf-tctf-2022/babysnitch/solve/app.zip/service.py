import grpc
import os
import sys
import json

import ui_pb2
import ui_pb2_grpc

class UIService(ui_pb2_grpc.UIServicer):
    def Ping(self, request, context):
        #print('ping')
        return ui_pb2.PingReply(id=request.id)

    def AskRule(self, request, context):
        #print('ask')
        rule = ui_pb2.Rule(name="any")
        return rule

    def Subscribe(self, node_config, context):
        #print('subscribe')
        conf = json.loads(node_config.config)
        conf['DefaultAction'] = "allow"
        node_config.config = json.dumps(conf)
        return node_config

    def Notifications(self, node_iter, context):
        #print('notification')
        return node_iter

