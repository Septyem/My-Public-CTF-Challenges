using honggfuzz commit 7eecfc991d0ae540d9773a6feb8fac5012a55ed6

remote server is newest Ubuntu:20.04 docker (IMAGE ID 9873176a8ff5) . find the libs yourself :)
